import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-debitcard',
  templateUrl: './debitcard.component.html',
  styleUrls: ['./debitcard.component.css']
})
export class DebitcardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
