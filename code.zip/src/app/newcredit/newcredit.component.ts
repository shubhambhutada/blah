import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-newcredit',
  templateUrl: './newcredit.component.html',
  styleUrls: ['./newcredit.component.css']
})
export class NewcreditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
