import { Component, OnInit } from '@angular/core';
import { Group } from '../model/group';
import { GroupService } from '../service/group.service';

@Component({
  selector: 'app-groups',
  templateUrl: './groups.component.html',
  styleUrls: ['./groups.component.css']
})
export class GroupsComponent implements OnInit {

  groups: Group[];
  newGroup: Group;

  constructor(private grpService: GroupService) {
    this.groups = [];
    this.newGroup = new Group();
  }

  ngOnInit() {
    this.load();
  }

  load() {
    this.grpService.getAll().subscribe(
      (data) => { this.groups = data; }
    );
  }

  edit(g: Group) {
    g.isEditing = true;
  }

  cancelEdit(g: Group) {
    g.isEditing = false;
  }

  add() {
    this.grpService.add(this.newGroup).subscribe(
      (data) => {
        this.newGroup = new Group();
        this.load();
      }
    );
  }

  save(g: Group) {
    this.grpService.update(g).subscribe(
      (data) => {
        this.load();
      }
    );
  }

  delete(gid: number) {
    if (confirm("Are you sure of deleting Group#"+gid)) {
      this.grpService.deleteById(gid).subscribe(
        () => {
          this.load();
        }
      );
    }
  }
}
