import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {DashboardComponent} from './dashboard/dashboard.component';
import {GroupsComponent} from './groups/groups.component';
import {ContactFormComponent} from './contact-form/contact-form.component';
import {SearchContactComponent} from './search-contact/search-contact.component';
import {ContactsListComponent} from './contacts-list/contacts-list.component';
import {CustomerComponent} from './customer/customer.component'
import {BankComponent } from './bank/bank.component';
import { DebitcardComponent } from './debitcard/debitcard.component';
import { CreditcardComponent } from './creditcard/creditcard.component';
import { ManagedebitComponent } from './managedebit/managedebit.component';
import { ManagecreditComponent } from './managecredit/managecredit.component';
import { NewdebitComponent } from './newdebit/newdebit.component';
import { NewcreditComponent } from './newcredit/newcredit.component';

const routes: Routes = [
  {path:'',component:DashboardComponent,pathMatch:'full'},
  {path:'groups',component:GroupsComponent},
  {path:'contacts',component:ContactsListComponent},
  {path:'newContact',component:ContactFormComponent},
  {path:'editContact/:contactId',component:ContactFormComponent},
  {path:'search',component:SearchContactComponent},
  {path:'customer',component:CustomerComponent},
  {path:'bank',component:BankComponent},
  {path:'debitcard',component:DebitcardComponent},
  {path:'creditcard',component:CreditcardComponent},
  {path:'manageexistingdebit',component:ManagedebitComponent},
  {path:'manageexisitngcredit',component:ManagecreditComponent},
  {path:'applynewdebit',component:NewdebitComponent},
  {path:'applynewcredit',component:NewcreditComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
