import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { GroupsComponent } from './groups/groups.component';
import { ContactsListComponent } from './contacts-list/contacts-list.component';
import { ContactFormComponent } from './contact-form/contact-form.component';
import { SearchContactComponent } from './search-contact/search-contact.component';
import { CustomerComponent } from './customer/customer.component';
import { BankComponent } from './bank/bank.component';
import { DebitcardComponent } from './debitcard/debitcard.component';
import { CreditcardComponent } from './creditcard/creditcard.component';
import { ManagedebitComponent } from './managedebit/managedebit.component';
import { ManagecreditComponent } from './managecredit/managecredit.component';
import { NewdebitComponent } from './newdebit/newdebit.component';
import { NewcreditComponent } from './newcredit/newcredit.component';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    GroupsComponent,
    ContactsListComponent,
    ContactFormComponent,
    SearchContactComponent,
    CustomerComponent,
    BankComponent,
    DebitcardComponent,
    CreditcardComponent,
    ManagedebitComponent,
    ManagecreditComponent,
    NewdebitComponent,
    NewcreditComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
