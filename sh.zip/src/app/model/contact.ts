export class Contact {
    public contactId:number;	
	public firstName:String ;	
	public middleName:string;	
	public lastName:string;	
	public gender:string;	
	public dateOfBirth:Date ;	
	public mobileNumber:string ;	
	public mailId:string ;	
	public whatsAppNumber:string ;	
	public faceBookId:string;	
	public groupName:string ;
}
